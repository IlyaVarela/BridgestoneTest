﻿using System.Text;

namespace AsociadosWebApi.Seguridad
{
    public class BasicAuthMiddleware
    {
        private readonly  RequestDelegate _next;
        private readonly IConfiguration _configuration;
        public BasicAuthMiddleware(RequestDelegate next, IConfiguration configuration) 
        {
            _next= next;
            _configuration= configuration;  
        }
        public async Task Invoke(HttpContext httpContext)
        { 
            string authHeader=httpContext.Request.Headers["Authorization"];
            var user = _configuration["AuthBasic:User"];
            var pass = _configuration["AuthBasic:Password"];
            if (authHeader != null) 
            {
                string auth = authHeader.Split(new char[] { ' ' })[1];
                Encoding encoding = Encoding.GetEncoding("UTF-8");  
                var usernameAndPassword=encoding.GetString(Convert.FromBase64String(auth));
                string username = usernameAndPassword.Split(new char[] { ':' })[0];
                string password = usernameAndPassword.Split(new char[] { ':' })[1];
                if (username == user && password == pass)
                {
                    await _next(httpContext);
                }
                else 
                {
                    httpContext.Response.StatusCode = 401;
                    await httpContext.Response.WriteAsync("Unauthorized");
                    return;
                }
            }
            else
            {
                httpContext.Response.StatusCode = 401;
                await httpContext.Response.WriteAsync("Unauthorized");
                return;
            }

        }
    }
}
