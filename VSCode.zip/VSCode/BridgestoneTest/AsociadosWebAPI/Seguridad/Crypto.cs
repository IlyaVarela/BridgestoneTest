﻿
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;
using System.Security.Cryptography;
using System.Text;


namespace AsociadosWebApi.Seguridad
{
    public class Crypto
    {        
        private readonly RSACryptoServiceProvider _privateKey;
        private readonly RSACryptoServiceProvider _publicKey;
        public Crypto(string pRutaLlavePublica, string pRutaLlavePrivada)
        {
            string public_pem = pRutaLlavePublica;//@"Seguridad\LlavesPem\clave_publica.pem";
            string private_pem = pRutaLlavePrivada;//@"Seguridad\LlavesPem\clave_privada.pem";
            _publicKey = GetPublicKeyFromPemFile(public_pem);
            _privateKey = GetPrivateKeyFromPemFile(private_pem);
        }
        private RSACryptoServiceProvider GetPublicKeyFromPemFile(String filePath)
        {
            using (TextReader publicKeyTextReader = new StringReader(File.ReadAllText(filePath)))
            {
                RsaKeyParameters publicKeyParam = (RsaKeyParameters)new PemReader(publicKeyTextReader).ReadObject();
                RSAParameters rsaParams = DotNetUtilities.ToRSAParameters((RsaKeyParameters)publicKeyParam);
                RSACryptoServiceProvider csp = new RSACryptoServiceProvider();
                csp.ImportParameters(rsaParams);
                return csp;
            }
        }
        private RSACryptoServiceProvider GetPrivateKeyFromPemFile(string filePath)
        {
            using (TextReader privateKeyTextReader = new StringReader(File.ReadAllText(filePath)))
            {
                AsymmetricCipherKeyPair readKeyPair = (AsymmetricCipherKeyPair)new PemReader(privateKeyTextReader).ReadObject();
                RSAParameters rsaParams = DotNetUtilities.ToRSAParameters((RsaPrivateCrtKeyParameters)readKeyPair.Private);
                RSACryptoServiceProvider csp = new RSACryptoServiceProvider();
                csp.ImportParameters(rsaParams);
                return csp;
            }
        }
        public string Encrypt(string text)
        {
            int maxLongitud = 244;
            string textoEncriptado = "";
            for (int i = 0; i < text.Length; i += maxLongitud)
            {
                int longitud = Math.Min(maxLongitud, text.Length - i);
                string segmento = text.Substring(i, longitud);
                var encryptedBytes = _publicKey.Encrypt(Encoding.UTF8.GetBytes(segmento),  false);
                textoEncriptado = textoEncriptado + Convert.ToBase64String(encryptedBytes);
            }
            return textoEncriptado;
        }
        public string Decrypt(string encrypted)
        {
            int maxLongitud = 344;
            string textoDesencriptado = "";
            for (int i = 0; i < encrypted.Length; i += maxLongitud)
            {
                int longitud = Math.Min(maxLongitud, encrypted.Length - i);
                string segmento = encrypted.Substring(i, longitud);
                var decryptedBytes = _privateKey.Decrypt(Convert.FromBase64String(segmento), false);
                textoDesencriptado = textoDesencriptado + Encoding.UTF8.GetString(decryptedBytes, 0, decryptedBytes.Length);
            }
            return textoDesencriptado;
        }
        public string ConsultaLlave()
        {
            using (TextReader privateKeyTextReader = new StringReader(File.ReadAllText(@"Seguridad\LlavesPem\clave_privada.pem")))
            {
                var ConsultaLlave = privateKeyTextReader.ReadToEnd();
                ConsultaLlave = ConsultaLlave.Replace("-----BEGIN RSA PRIVATE KEY-----", "");
                ConsultaLlave = ConsultaLlave.Replace("-----END RSA PRIVATE KEY-----", "");
                return Convert.ToString(ConsultaLlave);
            }
        }
    }
}
