﻿using System.Net;

namespace AsociadosWebApi.Seguridad
{
    public class IPWhitelistMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly List<string> _allowedEndpoints;

        public IPWhitelistMiddleware(RequestDelegate next, List<string> allowedEndpoints)
        {
            _next = next;
            _allowedEndpoints = allowedEndpoints;
        }

        public async Task Invoke(HttpContext context)
        {
            var remoteEndpoint = context.Connection.RemoteIpAddress.ToString() ;

            if (!_allowedEndpoints.Contains(remoteEndpoint))
            {
                context.Response.StatusCode = (int)HttpStatusCode.Forbidden;
                await context.Response.WriteAsync("Access denied.Endpoint: " + remoteEndpoint.ToString());
                return;
            }

            await _next(context);
        }
    }
}
