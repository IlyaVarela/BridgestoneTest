
using Microsoft.Extensions.Configuration;
using AsociadosWebApi.Seguridad;

namespace AsociadosWebAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }
            // Configuraci�n de la configuraci�n
            var configuration = builder.Configuration;

            app.UseMiddleware<BasicAuthMiddleware>();
            List<string> allowedEndpoints = configuration.GetSection("IPs_Permitidas").Get<List<string>>();
            //***** OJO Comentado porque localmente la IP que viene es ::1
            app.UseMiddleware<IPWhitelistMiddleware>(allowedEndpoints);

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
