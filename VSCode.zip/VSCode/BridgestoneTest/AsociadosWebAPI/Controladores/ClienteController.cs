﻿using Microsoft.AspNetCore.Mvc;
using AsociadosWebApi.Seguridad;
using AsociadosWebApi.Servicios;
using AsociadosWebApi.ModeloDatos.General;
using AsociadosWebApi.AccesoDatos;
using Newtonsoft.Json.Linq;
using AdquirentesWebApi.ModeloDatos;

namespace AsociadosWebApi.Controladores
{
    [ApiController]
    [Route("api/[controller]")]
    //controller for more general system inquiries
    public class ClienteController : ControllerBase
    {
        private readonly ClienteService proceso;
        private readonly Crypto descifra;
        public readonly string _connectionString;
        private MSSQLDataManager BaseDeDatos;

        public ClienteController(IConfiguration configuration)
        {
            proceso = new ClienteService(configuration);

            _connectionString = configuration.GetConnectionString("SQLDBConnection");
            BaseDeDatos = new MSSQLDataManager(_connectionString);
            JObject parametrosJSON = BaseDeDatos.SeleccionarParametros();
            //string RutaLlavePemPublica = parametrosJSON.GetValue("RUTA_LLAVE_PEM_PUBLICA_PARAMETROS").ToString();
            //string RutaLlavePemPrivada = parametrosJSON.GetValue("RUTA_LLAVE_PEM_PRIVADA_PARAMETROS").ToString();

            //descifra = new Crypto(RutaLlavePemPublica, RutaLlavePemPrivada);
            
        }

        #region CLIENTES 

        /// <summary>
        /// Metodo encriptado para listar Clientes
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("SeleccionarClientes")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> SeleccionarClientes()
        {
            try
            {
                RespuestaDTO resultado = await proceso.SeleccionarClientes();

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para insertar un Cliente
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("InsertarCliente")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> InsertarCliente([FromBody] ReqInsClienteDTO parametros)
        {
            try
            {
                string nombreCliente = parametros.NombreCliente ;
                double saldoCuenta = parametros.SaldoCuenta;

                RespuestaDTO resultado = await proceso.InsertarCliente(nombreCliente, saldoCuenta);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para eliminar un Cliente
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("EliminarCliente")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> EliminarCliente([FromBody] ReqEliClienteDTO parametros)
        {
            try
            {
                long idCliente = parametros.IdCliente;

                RespuestaDTO resultado = await proceso.EliminarCliente(idCliente);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para actualizar un Cliente
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("ActualizarCliente")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> ActualizarCliente([FromBody] ReqActClienteDTO parametros)
        {
            try
            {
                long idCliente = parametros.IdCliente;
                string nombreCliente = parametros.NombreCliente;
                double saldoCuenta = parametros.SaldoCuenta;

                RespuestaDTO resultado = await proceso.ActualizarCliente(idCliente , nombreCliente ,saldoCuenta);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        #endregion

        #region RETIRO_CAJERO 

        /// <summary>
        /// Metodo encriptado para realizar un retiro del cajero
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("RealizarRetiro")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> RealizarRetiro([FromBody] ReqRetirarEfectivoDTO parametros)
        {
            try
            {
                long idCliente = parametros.IdCliente;
                double montoRetiro = parametros.MontoRetiro ;

                RespuestaDTO resultado = await proceso.RealizarRetiro(idCliente,montoRetiro);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        #endregion

    }
}
