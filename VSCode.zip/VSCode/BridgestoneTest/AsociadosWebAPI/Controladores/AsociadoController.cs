﻿using Microsoft.AspNetCore.Mvc;
using AsociadosWebApi.Seguridad;
using AsociadosWebApi.Servicios;
using AsociadosWebApi.ModeloDatos.General;
using AsociadosWebApi.AccesoDatos;
using Newtonsoft.Json.Linq;
using AdquirentesWebApi.ModeloDatos;

namespace AsociadosWebApi.Controladores
{
    [ApiController]
    [Route("api/[controller]")]
    //controller for more general system inquiries
    public class AsociadoController : ControllerBase
    {
        private readonly AsociadoService proceso;
        private readonly Crypto descifra;
        public readonly string _connectionString;
        private MSSQLDataManager BaseDeDatos;

        public AsociadoController(IConfiguration configuration)
        {
            proceso = new AsociadoService(configuration);

            _connectionString = configuration.GetConnectionString("SQLDBConnection");
            BaseDeDatos = new MSSQLDataManager(_connectionString);
            JObject parametrosJSON = BaseDeDatos.SeleccionarParametros();
            //string RutaLlavePemPublica = parametrosJSON.GetValue("RUTA_LLAVE_PEM_PUBLICA_PARAMETROS").ToString();
            //string RutaLlavePemPrivada = parametrosJSON.GetValue("RUTA_LLAVE_PEM_PRIVADA_PARAMETROS").ToString();

            //descifra = new Crypto(RutaLlavePemPublica, RutaLlavePemPrivada);
            

        }

        #region DEPARTAMENTOS 

       
        /// <summary>
        /// Metodo encriptado para listar Departamentos
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("SeleccionarDepartamentos")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> SeleccionarDepartamentos()
        {
            try 
            {

                RespuestaDTO resultado = await proceso.SeleccionarDepartamentos();

                return resultado;
            }
            catch (Exception ex) {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para insertar un Departamento
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("InsertarDepartamento")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> InsertarDepartamento([FromBody] ReqInsDepartamentoDTO parametros)
        {
            try
            {
                string nombreDepartamento = parametros.NombreDepartamento;

                RespuestaDTO resultado = await proceso.InsertarDepartamento(nombreDepartamento);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para eliminar un Departamento
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("EliminarDepartamento")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> EliminarDepartamento([FromBody] ReqEliDepartamentoDTO parametros)
        {
            try
            {
                long idDepartamento = parametros.IdDepartamento;

                RespuestaDTO resultado = await proceso.EliminarDepartamento(idDepartamento);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para actualizar un Departamento
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("ActualizarDepartamento")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> ActualizarDepartamento([FromBody] ReqActDepartamentoDTO parametros)
        {
            try
            {
                long idDepartamento = parametros.IdDepartamento;
                string nombreDepartamento = parametros.NombreDepartamento;

                RespuestaDTO resultado = await proceso.ActualizarDepartamento(idDepartamento, nombreDepartamento);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }


        #endregion

        #region ASOCIADOS 


        /// <summary>
        /// Metodo encriptado para listar Asociados
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("SeleccionarAsociados")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> SeleccionarAsociados()
        {
            try
            {

                RespuestaDTO resultado = await proceso.SeleccionarAsociados();

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para insertar un Asociado
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("InsertarAsociado")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> InsertarAsociado([FromBody] ReqInsAsociadoDTO parametros)
        {
            try
            {
                string nombreAsociado = parametros.NombreAsociado ;
                double salarioAsociado = parametros.SalarioAsociado;
                long idDepartamento = parametros.DepartamentoAsociado;

                RespuestaDTO resultado = await proceso.InsertarAsociado(nombreAsociado, salarioAsociado, idDepartamento);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para eliminar un Asociado
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("EliminarAsociado")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> EliminarAsociado([FromBody] ReqEliAsociadoDTO parametros)
        {
            try
            {
                long idAsociado = parametros.IdAsociado;

                RespuestaDTO resultado = await proceso.EliminarAsociado(idAsociado);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para actualizar un Asociado
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("ActualizarAsociado")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> ActualizarAsociado([FromBody] ReqActAsociadoDTO parametros)
        {
            try
            {
                long idAsociado = parametros.IdAsociado;
                string nombreAsociado = parametros.NombreAsociado;
                double salarioAsociado = parametros.SalarioAsociado;
                long idDepartamento = parametros.DepartamentoAsociado;

                RespuestaDTO resultado = await proceso.ActualizarAsociado(idAsociado, nombreAsociado,salarioAsociado, idDepartamento);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }


        #endregion

        #region AUMENTO_SALARIO 


        /// <summary>
        /// Metodo encriptado para aumentar salario a todos los asociados
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("AumentarSalarioGeneral")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> AumentarSalarioGeneral([FromBody] ReqAumentarSalarioGeneralDTO parametros)
        {
            try
            {
                double porcentajeAumento = parametros.PorcentajeAumento;

                RespuestaDTO resultado = await proceso.AumentarSalarioGeneral(porcentajeAumento);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        /// <summary>
        /// Metodo encriptado para aumentar salario por departamentos
        /// </summary>
        /// <param name="parametros"></param>
        /// <returns></returns>
        [Route("AumentarSalarioPorDepartamento")]
        [HttpPost]
        public async Task<ActionResult<RespuestaDTO>> AumentarSalarioPorDepartamento([FromBody] ReqAumentarSalarioPorDepartamentoDTO parametros)
        {
            try
            {
                
                double porcentajeAumento = parametros.PorcentajeAumento;
                long idDepartamento = parametros.IdDepartamento;

                RespuestaDTO resultado = await proceso.AumentarSalarioPorDepartamento(porcentajeAumento, idDepartamento);

                return resultado;
            }
            catch (Exception ex)
            {
                return new RespuestaDTO() { CodigoMensaje = "9", DescripcionMensaje = ex.Message };
            }
        }

        #endregion



    }
}
