﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqInsDepartamentoDTO
    {
        public string NombreDepartamento { get; set; }
    }
}
