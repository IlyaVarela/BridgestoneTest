﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqAumentarSalarioGeneralDTO
    {
        public double PorcentajeAumento { get; set; }
    }
}
