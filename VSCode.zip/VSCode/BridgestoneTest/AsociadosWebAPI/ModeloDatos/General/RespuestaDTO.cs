﻿namespace AsociadosWebApi.ModeloDatos.General
{
    /// <summary>
    /// Descripción: Clase que representa una Respuesta.
    /// Fecha de creación: 18-08-2024
    /// </summary>
    public class RespuestaDTO
    {
        /// <summary>
        /// Descripción: Código de la respuesta obtenida.
        /// </summary>
        public string CodigoMensaje { get; set; }
        /// <summary>
        /// Descripción: Descripción de la respuesta obtenida.
        /// </summary>
        public string DescripcionMensaje { get; set; }

        public RespuestaDTO()
        {
            CodigoMensaje = "0";
            DescripcionMensaje = "Proceso realizado satisfactoriamente";
        }
    }
}
