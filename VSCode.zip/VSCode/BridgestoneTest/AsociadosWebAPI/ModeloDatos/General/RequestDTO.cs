﻿namespace AdquirentesWebApi.ModeloDatos.General
{

    public class RequestDTO
    {
        public string Text { get; set; }
    }
}
