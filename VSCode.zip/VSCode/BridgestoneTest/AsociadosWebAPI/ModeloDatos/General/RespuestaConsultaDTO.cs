﻿namespace AsociadosWebApi.ModeloDatos.General
{
    /// <summary>
    /// Descripción: Clase que representa una Respuesta con datos de un select.
    /// Fecha de creación: 18-08-2024
    /// </summary>
    public class RespuestaConsultaDTO<T>:RespuestaDTO
    {
        /// <summary>
        /// Descripción: Lista de items de la respuesta obtenida
        /// </summary>
        public List<T> Items { get; set; }
    }
}
