﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqActAsociadoDTO
    {
        public long IdAsociado { get; set; }
        public string NombreAsociado { get; set; }
        public double SalarioAsociado { get; set; }
        public long DepartamentoAsociado { get; set; }
    }
}
