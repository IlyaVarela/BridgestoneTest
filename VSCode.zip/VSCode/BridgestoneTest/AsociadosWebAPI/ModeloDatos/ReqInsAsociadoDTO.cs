﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqInsAsociadoDTO {
        public string NombreAsociado { get; set; }
        public double SalarioAsociado { get; set; }
        public long DepartamentoAsociado { get; set; }
    }
}
