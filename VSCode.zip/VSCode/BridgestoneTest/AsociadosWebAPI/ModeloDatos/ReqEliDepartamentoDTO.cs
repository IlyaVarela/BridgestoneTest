﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqEliDepartamentoDTO
    {
        public long IdDepartamento { get; set; }
    }
}
