﻿namespace AsociadosWebAPI.ModeloDatos
{
    public class AsociadoDTO
    {
        public long IdAsociado { get; set; }
        public string NombreAsociado { get; set; }
        public double SalarioAsociado { get; set; }
        public long IdDepartamentoAsociado { get; set; }
        public string NombreDepartamentoAsociado { get; set; }

    }
}
