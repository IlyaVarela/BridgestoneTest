﻿namespace AsociadosWebAPI.ModeloDatos
{
    public class DepartamentoDTO
    {
        public long IdDepartamento { get; set; }
        public string NombreDepartamento { get; set; }

    }
}
