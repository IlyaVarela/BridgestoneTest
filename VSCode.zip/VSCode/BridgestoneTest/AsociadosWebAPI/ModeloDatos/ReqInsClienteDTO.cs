﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqInsClienteDTO
    {
        public string NombreCliente { get; set; }
        public double SaldoCuenta { get; set; }
    }
}
