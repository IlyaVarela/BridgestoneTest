﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqAumentarSalarioPorDepartamentoDTO
    {
        public long IdDepartamento { get; set; }
        public double PorcentajeAumento { get; set; }
    }
}
