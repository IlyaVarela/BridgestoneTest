﻿namespace AsociadosWebAPI.ModeloDatos
{
    public enum E_Tipo_Efectivo: ushort
    {
        Moneda = 1,
        Billete = 2
    }
        
    public class EfectivoDTO
    {
        public E_Tipo_Efectivo Tipo_Efectivo { get; set; }
        public long Denominacion { get; set; }
        public long Cantidad { get; set; }

    }
}
