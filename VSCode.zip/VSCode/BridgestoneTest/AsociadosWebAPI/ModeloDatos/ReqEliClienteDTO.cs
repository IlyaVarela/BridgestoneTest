﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqEliClienteDTO
    {
        public long IdCliente { get; set; }
    }
}
