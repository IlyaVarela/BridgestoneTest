﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqActDepartamentoDTO
    {
        public long IdDepartamento { get; set; }
        public string NombreDepartamento { get; set; }
    }
}
