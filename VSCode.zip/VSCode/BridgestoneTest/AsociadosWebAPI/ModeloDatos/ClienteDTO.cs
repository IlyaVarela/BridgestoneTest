﻿namespace AsociadosWebAPI.ModeloDatos
{
    public class ClienteDTO
    {
        public long IdCliente { get; set; }
        public string NombreCliente { get; set; }
        public double SaldoCuenta { get; set; }
       

    }
}
