﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqEliAsociadoDTO
    {
        public long IdAsociado { get; set; }
    }
}
