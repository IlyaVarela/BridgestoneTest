﻿namespace AdquirentesWebApi.ModeloDatos
{

    public class ReqRetirarEfectivoDTO
    {
        public long IdCliente { get; set; }
        public double MontoRetiro { get; set; }
    }
}
