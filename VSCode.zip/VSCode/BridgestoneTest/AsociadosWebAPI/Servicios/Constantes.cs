﻿namespace AsociadosWebApi.Servicios

{
    public class EnumDatos
    {
        public const string CODIGO_EXITO = "0";
        public const string DESCRIPCION_EXITO = "Proceso finalizado exitosamente.";
        public const string CODIGO_EXITO_SIN_CORREO = "1";
        public const string DESCRIPCION_EXITO_SIN_CORREO = "Proceso finalizado parcialmente exitoso. Error al enviar el correo electrónico.";

        public const string CODIGO_ERROR = "99";
        public const string DESCRIPCION_ERROR = "Ha ocurrido un error en la aplicación.";
        public const string CODIGO_ERROR_DETALLE = "98";
        public const string DESCRIPCION_ERROR_DETALLE = "Ha ocurrido un error en la aplicación, detalle técnico: ";
        public const string CODIGO_ERROR_NO_RESULTS = "97";
        public const string DESCRIPCION_ERROR_NO_RESULTS = "No se encontraron registros.";
        public const string CODIGO_ERROR_MAX_SIZE = "96";
        public const string DESCRIPCION_ERROR_MAX_SIZE = "No se puede guardar el archivo, sobrepasa el tamaño máximo permitido.";
        public const string CODIGO_ERROR_DOCUMENT = "95";
        public const string DESCRIPCION_ERROR_DOCUMENT = "No se encontró el documento.";

        public const string CODIGO_ERROR_WRONG_PASSWORD = "94";
        public const string DESCRIPCION_ERROR_WRONG_PASSWORD = "Contraseña incorrecta favor verificar.";

        public const string CODIGO_ERROR_NO_REGISTER = "93";
        public const string DESCRIPCION_ERROR_NO_REGISTER = "Usuario no registrado.";

        public const string DESCRIPCION_PROCESO = "Proceso iniciado";
        public const string DESCRIPCION_PROCESO_EMAIL_ENVIO = "Enviando correo electronico";
        public const string DESCRIPCION_ID_NOT_FOUND = "No se localizan datos para el número de identificación: ";
        public const string DESCRIPCION_PASS_NOT_MATCH = "Contraseña inválida, la contraseña actual no es la misma.";
        public const string DESCRIPCION_ERROR_OTP = "Ha ocurrido un error en la aplicación. No se pudo verificar el código OTP.";

        
    }
}
