﻿using AsociadosWebApi.AccesoDatos;
using AsociadosWebApi.ModeloDatos.General;
using AsociadosWebApi.Seguridad;
using AsociadosWebApi.ModeloDatos;
using System.Data;
using System.Security.Principal;
using Microsoft.AspNetCore.Mvc.RazorPages;
using AsociadosWebAPI.ModeloDatos;

namespace AsociadosWebApi.Servicios
{
    public class AsociadoService
    {
        public IConfiguration Configuration { get; }
        public readonly string _connectionString;
        private readonly string UsuarioLogsBD;
        private MSSQLDataManager BaseDeDatos;
       
        public AsociadoService(IConfiguration configuration)
        {
            Configuration = configuration;
            _connectionString = configuration.GetConnectionString("SqlDBConnection");
            BaseDeDatos = new MSSQLDataManager(_connectionString);
            UsuarioLogsBD = configuration.GetSection("AppConfig")["UsuarioLogsBDAsociados"];
            
        }

        #region "DEPARTAMENTOS"

        public async Task<RespuestaConsultaDTO<DepartamentoDTO>> SeleccionarDepartamentos()
        {
            RespuestaConsultaDTO<DepartamentoDTO> respuesta = new RespuestaConsultaDTO<DepartamentoDTO>();
            List<DepartamentoDTO> departamentos = new List<DepartamentoDTO>();
            try
            {
                BaseDeDatos.InsertarBitacora("SeleccionarDepartamentos",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    departamentos = BaseDeDatos.SeleccionarDepartamentos();
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;
                    respuesta.Items=departamentos;
                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR  ;
                    BaseDeDatos.InsertarBitacora("SeleccionarDepartamentos",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR LISTANDO DEPARTAMENTOS|"+ ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("SeleccionarDepartamentos",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("SeleccionarDepartamentos",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> InsertarDepartamento(string pNombreDepartamento)
        {
            RespuestaDTO respuesta = new RespuestaDTO();
            
            try
            {
                BaseDeDatos.InsertarBitacora("InsertarDepartamento",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.InsertarDepartamento(pNombreDepartamento);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;
                    
                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("InsertarDepartamento",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR INSERTANDO DEPARTAMENTO|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("InsertarDepartamento",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("InsertarDepartamento",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> EliminarDepartamento(long pIdDepartamento)
        {
            RespuestaDTO respuesta = new RespuestaDTO();

            try
            {
                BaseDeDatos.InsertarBitacora("EliminarDepartamento",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.EliminarDepartamento(pIdDepartamento);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;

                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("EliminarDepartamento",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR ELIMINANDO DEPARTAMENTO|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("EliminarDepartamento",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("EliminarDepartamento",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> ActualizarDepartamento(long pIdDepartamento,
                                                                string pNombreDepartamento)
        {
            RespuestaDTO respuesta = new RespuestaDTO();

            try
            {
                BaseDeDatos.InsertarBitacora("ActualizarDepartamento",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.ActualizarDepartamento(pIdDepartamento,pNombreDepartamento );
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;

                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("ActualizarDepartamento",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                    "ERROR ACTUALIZANDO DEPARTAMENTO|" + ex.Message,
                                                    UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("ActualizarDepartamento",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("ActualizarDepartamento",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        #endregion

        #region "ASOCIADOS"

        public async Task<RespuestaConsultaDTO<AsociadoDTO>> SeleccionarAsociados()
        {
            RespuestaConsultaDTO<AsociadoDTO> respuesta = new RespuestaConsultaDTO<AsociadoDTO>();
            List<AsociadoDTO> asociados = new List<AsociadoDTO>();
            try
            {
                BaseDeDatos.InsertarBitacora("SeleccionarAsociados",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    asociados = BaseDeDatos.SeleccionarAsociados();
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;
                    respuesta.Items = asociados;
                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("SeleccionarAsociados",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR LISTANDO ASOCIADOS|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("SeleccionarAsociados",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<AsociadoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("SeleccionarAsociados",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> InsertarAsociado(string pNombreAsociado,
                                                                double pSalarioAsociado,
                                                                long pIdDepartamento)
        {
            RespuestaDTO respuesta = new RespuestaDTO();

            try
            {
                BaseDeDatos.InsertarBitacora("InsertarAsociado",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.InsertarAsociado(pNombreAsociado, 
                                                        pSalarioAsociado,
                                                        pIdDepartamento);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;

                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("InsertarAsociado",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR INSERTANDO ASOCIADO|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("InsertarAsociado",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("InsertarAsociado",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> EliminarAsociado(long pIdAsociado)
        {
            RespuestaDTO respuesta = new RespuestaDTO();

            try
            {
                BaseDeDatos.InsertarBitacora("EliminarAsociado",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.EliminarAsociado(pIdAsociado);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;

                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("EliminarAsociado",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR ELIMINANDO ASOCIADO|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("EliminarAsociado",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("EliminarAsociado",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> ActualizarAsociado(long pIdAsociado,
                                                            string pNombreAsociado,
                                                            double pSalarioAsociado,
                                                            long pIdDepartamento)
        {
            RespuestaDTO respuesta = new RespuestaDTO();

            try
            {
                BaseDeDatos.InsertarBitacora("ActualizarAsociado",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.ActualizarAsociado( pIdAsociado,
                                             pNombreAsociado,
                                             pSalarioAsociado,
                                             pIdDepartamento);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;

                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("ActualizarAsociado",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                    "ERROR ACTUALIZANDO ASOCIADO|" + ex.Message,
                                                    UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("ActualizarAsociado",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("ActualizarAsociado",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        #endregion

        #region "AUMENTAR_SALARIO"

        public async Task<RespuestaDTO> AumentarSalarioGeneral(double pPorcentajeAumento)
        {
            RespuestaDTO respuesta = new RespuestaDTO();
            
            try
            {
                BaseDeDatos.InsertarBitacora("AumentarSalarioGeneral",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.AumentarSalarioGeneral(pPorcentajeAumento);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;
                    
                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("AumentarSalarioGeneral",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR AUMENTANDO SALARIO GENERAL|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("AumentarSalarioGeneral",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<AsociadoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("AumentarSalarioGeneral",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> AumentarSalarioPorDepartamento(double pPorcentajeAumento,
                                                                long pIdDepartamento)
        {
            RespuestaDTO respuesta = new RespuestaDTO();

            try
            {
                BaseDeDatos.InsertarBitacora("AumentarSalarioPorDepartamento",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.AumentarSalarioPorDepartamento(pPorcentajeAumento,
                                                        pIdDepartamento);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;

                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("AumentarSalarioPorDepartamento",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR AUMENTANDO SALARIO POR DEPARTAMENTO|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("AumentarSalarioPorDepartamento",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("AumentarSalarioPorDepartamento",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        

        #endregion



    }
}
