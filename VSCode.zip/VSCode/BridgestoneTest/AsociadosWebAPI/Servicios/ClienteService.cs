﻿using AsociadosWebApi.AccesoDatos;
using AsociadosWebApi.ModeloDatos.General;
using AsociadosWebApi.Seguridad;
using AsociadosWebApi.ModeloDatos;
using System.Data;
using System.Security.Principal;
using Microsoft.AspNetCore.Mvc.RazorPages;
using AsociadosWebAPI.ModeloDatos;
using Microsoft.Data.SqlClient;

namespace AsociadosWebApi.Servicios
{
    public class ClienteService
    {
        public IConfiguration Configuration { get; }
        public readonly string _connectionString;
        private readonly string UsuarioLogsBD;
        private MSSQLDataManager BaseDeDatos;
       
        public ClienteService(IConfiguration configuration)
        {
            Configuration = configuration;
            _connectionString = configuration.GetConnectionString("SqlDBConnection");
            BaseDeDatos = new MSSQLDataManager(_connectionString);
            UsuarioLogsBD = configuration.GetSection("AppConfig")["UsuarioLogsBDClientes"];
            
        }

        #region "CLIENTES"

        public async Task<RespuestaConsultaDTO<ClienteDTO>> SeleccionarClientes()
        {
            RespuestaConsultaDTO<ClienteDTO> respuesta = new RespuestaConsultaDTO<ClienteDTO>();
            List<ClienteDTO> clientes = new List<ClienteDTO>();
            try
            {
                BaseDeDatos.InsertarBitacora("SeleccionarAsociados",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    clientes = BaseDeDatos.SeleccionarClientes();
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;
                    respuesta.Items = clientes;
                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("SeleccionarClientes",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR LISTANDO CLIENTES|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("SeleccionarClientes",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<ClienteDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("SeleccionarClientes",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> InsertarCliente(string pNombreCliente,
                                                                double pSaldoCuenta)
        {
            RespuestaDTO respuesta = new RespuestaDTO();

            try
            {
                BaseDeDatos.InsertarBitacora("InsertarCliente",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.InsertarCliente(pNombreCliente,
                                                        pSaldoCuenta);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;

                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("InsertarCliente",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR INSERTANDO CLIENTE|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("InsertarCliente",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("InsertarCliente",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> EliminarCliente(long pIdCliente)
        {
            RespuestaDTO respuesta = new RespuestaDTO();

            try
            {
                BaseDeDatos.InsertarBitacora("EliminarCliente",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.EliminarCliente(pIdCliente);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;

                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("EliminarCliente",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR ELIMINANDO CLIENTE|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("EliminarCliente",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("EliminarCliente",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        public async Task<RespuestaDTO> ActualizarCliente(long pIdCliente,
                                                            string pNombreCliente,
                                                            double pSaldoCuenta)
        {
            RespuestaDTO respuesta = new RespuestaDTO();

            try
            {
                BaseDeDatos.InsertarBitacora("ActualizarCliente",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {
                    BaseDeDatos.ActualizarCliente( pIdCliente,
                                             pNombreCliente,
                                             pSaldoCuenta);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;

                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("ActualizarCliente",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                    "ERROR ACTUALIZANDO CLIENTE|" + ex.Message,
                                                    UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("ActualizarCliente",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<DepartamentoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("ActualizarCliente",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        #endregion

        #region "RETIRO_CAJERO"

        public async Task<RespuestaConsultaDTO<EfectivoDTO>> RealizarRetiro(long pIdCliente, 
                                                                            double pMontoRetiro)
        {
            RespuestaConsultaDTO<EfectivoDTO> respuesta = new RespuestaConsultaDTO<EfectivoDTO>();

            try
            {
                BaseDeDatos.InsertarBitacora("RealizarRetiro",
                                                                "",
                                                                "INICIO",
                                                                UsuarioLogsBD);
                try
                {

                    List<EfectivoDTO> efectivo = CalcularEfectivo(pMontoRetiro);
                    BaseDeDatos.RealizarRetiro(pIdCliente, pMontoRetiro);
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_EXITO;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_EXITO;
                    respuesta.Items = efectivo;
                }
                catch (Exception ex)
                {
                    respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                    respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                    BaseDeDatos.InsertarBitacora("RealizarRetiro",
                                                EnumDatos.DESCRIPCION_ERROR,
                                                 "ERROR REALIZANDO RETIRO|" + ex.Message,
                                                 UsuarioLogsBD);
                    return respuesta;
                }
                BaseDeDatos.InsertarBitacora("RealizarRetiro",
                                                EnumDatos.DESCRIPCION_EXITO,
                                                "FIN",
                                                UsuarioLogsBD);
                return respuesta;
            }
            catch (Exception ex)
            {
                RespuestaConsultaDTO<AsociadoDTO> response = new();
                respuesta.CodigoMensaje = EnumDatos.CODIGO_ERROR;
                respuesta.DescripcionMensaje = EnumDatos.DESCRIPCION_ERROR;
                BaseDeDatos.InsertarBitacora("RealizarRetiro",
                                            EnumDatos.DESCRIPCION_ERROR,
                                            "EXCEPTION|" + ex.Message,
                                            UsuarioLogsBD);
                return respuesta;
            }
        }

        #endregion

        #region "FUNCIONES"

        public List<EfectivoDTO> CalcularEfectivo(double pMontoRetiro)
        {
            try
            {
                List<long> Billetes = new List<long> { 1000, 500, 200, 100, 50, 20 };
                List<long> Monedas = new List<long> { 10, 5, 2, 1 };
                List<EfectivoDTO> efectivo = new List<EfectivoDTO>();

                if (pMontoRetiro % 1 != 0)
                {
                    throw new ArgumentException("El monto debe ser un número entero sin decimales.");
                }

                long montoEntero = (long)pMontoRetiro;
                long montoRestante = montoEntero;
                // Descomponer en billetes
                foreach (var billete in Billetes)
                {
                    if (montoRestante <= 0)
                    { 
                        break; 
                    }
                    long cantidadBilletes = montoRestante / billete;
                    if (cantidadBilletes > 0)
                    {
                        efectivo.Add(new EfectivoDTO
                        {
                            Tipo_Efectivo = E_Tipo_Efectivo.Billete,
                            Denominacion = billete,
                            Cantidad = cantidadBilletes
                        });

                        montoRestante -= cantidadBilletes * billete;
                    }
                }

                // Descomponer en monedas
                foreach (var moneda in Monedas)
                {
                    if (montoRestante <= 0)
                    {
                        break;
                    }
                    long cantidadMonedas = montoRestante / moneda;
                    if (cantidadMonedas > 0)
                    {
                        efectivo.Add(new EfectivoDTO
                        {
                            Tipo_Efectivo = E_Tipo_Efectivo.Moneda,
                            Denominacion = moneda,
                            Cantidad = cantidadMonedas
                        });
                        montoRestante -= cantidadMonedas * moneda;
                    }
                }

                // Si aún queda algún monto restante (debería ser 0 si todo está bien), manejarlo
                if (montoRestante > 0)
                {
                    throw new Exception("No se puede descomponer el monto completamente con las denominaciones disponibles.");
                }

                return efectivo;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        #endregion

    }
}
