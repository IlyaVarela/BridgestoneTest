﻿//using AdquirentesWebApi.ModeloDatos.Proceso;
//using AdquirentesWebApi.Servicios;
using Newtonsoft.Json.Linq;
using System;
using System.Data;
using Microsoft.Data.SqlClient;
using static AsociadosWebApi.AccesoDatos.EnumBaseDatos;
using Newtonsoft.Json;
using AsociadosWebApi.ModeloDatos.General;
using AsociadosWebAPI.ModeloDatos;

namespace AsociadosWebApi.AccesoDatos
{
    public class MSSQLDataManager
    {
        private MSSQLDataAccess dataAccess;
        public MSSQLDataManager(string connectionString)
        { 
            dataAccess = new MSSQLDataAccess(connectionString);
        }
        public void InsertarBitacora(string service, string detail, string values, string user ) {
            try
            {
                // Construir la descripción de los valores
                string descValores = string.IsNullOrWhiteSpace(values) ? string.Empty : "Valores: " + values;

                // Crear los parámetros para el stored procedure
                SqlParameter paramService = new SqlParameter("@servicio", SqlDbType.NVarChar, 100)
                {
                    Value = service
                };

                SqlParameter paramDetalle = new SqlParameter("@detalle", SqlDbType.NVarChar, 4000)
                {
                    Value = $"{detail} {descValores}".Trim()
                };

                SqlParameter paramAdicionadoPor = new SqlParameter("@usuario", SqlDbType.NVarChar, 100)
                {
                    Value = user
                };

                // Llamar al método para ejecutar el stored procedure
                dataAccess.ExecuteStoredProcedureNonQuery("sp_insertar_bitacora", new SqlParameter[] { paramService, paramDetalle, paramAdicionadoPor });
            }
            catch (Exception ex)
            {
                // Manejar la excepción
                throw new Exception(ex.Message);
            }
        }
        public JObject SeleccionarParametros()
        {
            try
            {
                JObject ParametrosJOBJECT = new JObject();
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                {
                    Direction = ParameterDirection.Output
                };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                {
                    Direction = ParameterDirection.Output
                };
                DataTable data = dataAccess.ExecuteStoredProcedureReader("sp_seleccionar_parametros", new SqlParameter[] { paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;

                foreach (DataRow row in data.Rows)
                {
                    ParametrosJOBJECT[row["Parametro"].ToString()] = row["Valor"].ToString();


                }

                

                return ParametrosJOBJECT;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        # region "DEPARTAMENTOS"

        public List<DepartamentoDTO> SeleccionarDepartamentos()
        {
            try
            {
                List<DepartamentoDTO> departamentos = new List<DepartamentoDTO>();
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                {Direction = ParameterDirection.Output};
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                {Direction = ParameterDirection.Output};
                DataTable data = dataAccess.ExecuteStoredProcedureReader("sp_seleccionar_departamentos", 
                                                        new SqlParameter[] { paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;

                foreach (DataRow row in data.Rows)
                {
                    departamentos.Add(new DepartamentoDTO 
                    {
                        IdDepartamento = long.Parse(row["Id_Departamento"].ToString()),
                        NombreDepartamento = row["Nombre_Departamento"].ToString()
                    });
                }
                return departamentos;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void InsertarDepartamento(string pNombreDepartamento)
        {
            try
            {
                SqlParameter paramNombreDepartamento = new SqlParameter("@nombreDepartamento", SqlDbType.VarChar,100)
                {Value = pNombreDepartamento , Direction = ParameterDirection.Input} ;
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_insertar_departamento",
                                       new SqlParameter[] {paramNombreDepartamento, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;

               
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void EliminarDepartamento(long pIdDepartamento)
        {
            try
            {
                SqlParameter paramIdDepartamento = new SqlParameter("@idDepartamento", SqlDbType.BigInt)
                { Value = pIdDepartamento, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_eliminar_departamento",
                                       new SqlParameter[] { paramIdDepartamento, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void ActualizarDepartamento(long pIdDepartamento,
                                            string pNombreDepartamento)
        {
            try
            {
                SqlParameter paramIdDepartamento = new SqlParameter("@idDepartamento", SqlDbType.BigInt)
                { Value = pIdDepartamento, Direction = ParameterDirection.Input };
                SqlParameter paramNombreDepartamento = new SqlParameter("@nombreDepartamento", SqlDbType.VarChar, 100)
                { Value = pNombreDepartamento, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_actualizar_departamento",
                                       new SqlParameter[] { paramIdDepartamento,paramNombreDepartamento,paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion

        # region "ASOCIADOS"

        public List<AsociadoDTO> SeleccionarAsociados()
        {
            try
            {
                List<AsociadoDTO> asociados = new List<AsociadoDTO>();
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                DataTable data = dataAccess.ExecuteStoredProcedureReader("sp_seleccionar_asociados",
                                                        new SqlParameter[] { paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;

                foreach (DataRow row in data.Rows)
                {
                    asociados.Add(new AsociadoDTO
                    {
                        IdAsociado = long.Parse(row["Id_Asociado"].ToString()),
                        NombreAsociado = row["Nombre_Asociado"].ToString(),
                        SalarioAsociado = Convert.ToDouble( row["Salario_Asociado"].ToString()),
                        IdDepartamentoAsociado = long.Parse(row["Id_Departamento"].ToString()),
                        NombreDepartamentoAsociado= row["Nombre_Departamento"].ToString()
                    });
                }
                return asociados;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void InsertarAsociado(string pNombreAsociado,
                                        double pSalarioAsociado,
                                        long pIdDepartamento)
        {
            try
            {
                SqlParameter paramNombreAsociado = new SqlParameter("@nombreAsociado", SqlDbType.VarChar, 100)
                { Value = pNombreAsociado, Direction = ParameterDirection.Input };
                SqlParameter paramSalarioAsociado = new SqlParameter("@salarioAsociado", SqlDbType.Decimal)
                { Value = pSalarioAsociado, Precision = 18, Scale = 2, Direction = ParameterDirection.Input };
                SqlParameter paramIdDepartamento = new SqlParameter("@idDepartamento", SqlDbType.BigInt)
                { Value = pIdDepartamento, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_insertar_asociado",
                                       new SqlParameter[] { paramNombreAsociado, paramSalarioAsociado, paramIdDepartamento, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void EliminarAsociado(long pIdAsociado)
        {
            try
            {
                SqlParameter paramIdAsociado = new SqlParameter("@idAsociado", SqlDbType.BigInt)
                { Value = pIdAsociado, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_eliminar_asociado",
                                       new SqlParameter[] { paramIdAsociado, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void ActualizarAsociado(long pIdAsociado,
                                            string pNombreAsociado,
                                            double pSalarioAsociado,
                                            long pIdDepartamento)
        {
            try
            {
                SqlParameter paramIdAsociado = new SqlParameter("@idAsociado", SqlDbType.BigInt)
                { Value = pIdAsociado , Direction = ParameterDirection.Input };
                SqlParameter paramNombreAsociado = new SqlParameter("@nombreAsociado", SqlDbType.VarChar, 100)
                { Value = pNombreAsociado, Direction = ParameterDirection.Input };
                SqlParameter paramSalarioAsociado = new SqlParameter("@salarioAsociado", SqlDbType.Decimal)
                { Value = pSalarioAsociado, Precision = 18, Scale = 2, Direction = ParameterDirection.Input };
                SqlParameter paramIdDepartamento = new SqlParameter("@idDepartamento", SqlDbType.BigInt)
                { Value = pIdDepartamento, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_actualizar_asociado",
                                       new SqlParameter[] { paramIdAsociado, paramNombreAsociado, paramSalarioAsociado, paramIdDepartamento, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion

        # region "AUMENTAR_SALARIO"

        public void AumentarSalarioGeneral(double pPorcentajeAumento)
        {
            try
            {

                SqlParameter paramPorcentajeAumento = new SqlParameter("@porcentajeAumento", SqlDbType.Decimal)
                { Value = pPorcentajeAumento, Precision = 18, Scale = 2, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureReader("sp_aumentar_salario_general",
                                                        new SqlParameter[] { paramPorcentajeAumento,paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;

                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void AumentarSalarioPorDepartamento(double pPorcentajeAumento,
                                        long pIdDepartamento)
        {
            try
            {
                
                SqlParameter paramPorcentajeAumento = new SqlParameter("@porcentajeAumento", SqlDbType.Decimal)
                { Value = pPorcentajeAumento, Precision = 18, Scale = 2, Direction = ParameterDirection.Input };
                SqlParameter paramIdDepartamento = new SqlParameter("@idDepartamento", SqlDbType.BigInt)
                { Value = pIdDepartamento, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                DataTable data = dataAccess.ExecuteStoredProcedureReader("sp_aumentar_salario_por_departamento",
                                       new SqlParameter[] {  paramPorcentajeAumento, paramIdDepartamento, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        #endregion

        #region "CLIENTES"

        public List<ClienteDTO> SeleccionarClientes()
        {
            try
            {
                List<ClienteDTO> clientes = new List<ClienteDTO>();
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                DataTable data = dataAccess.ExecuteStoredProcedureReader("sp_seleccionar_clientes",
                                                        new SqlParameter[] { paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;

                foreach (DataRow row in data.Rows)
                {
                    clientes.Add(new ClienteDTO
                    {
                        IdCliente = long.Parse(row["Id_Cliente"].ToString()),
                        NombreCliente = row["Nombre_Cliente"].ToString(),
                        SaldoCuenta = Convert.ToDouble(row["Saldo_Cuenta"].ToString())
                    });
                }
                return clientes;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void InsertarCliente(string pNombreCliente,
                                        double pSaldoCuenta)
        {
            try
            {
                SqlParameter paramNombreCliente = new SqlParameter("@nombreCliente", SqlDbType.VarChar, 100)
                { Value = pNombreCliente, Direction = ParameterDirection.Input };
                SqlParameter paramSaldoCuenta = new SqlParameter("@saldoCuenta", SqlDbType.Decimal)
                { Value = pSaldoCuenta, Precision = 18, Scale = 2, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_insertar_cliente",
                                       new SqlParameter[] { paramNombreCliente, paramSaldoCuenta, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void EliminarCliente(long pIdCliente)
        {
            try
            {
                SqlParameter paramIdCliente = new SqlParameter("@idCliente", SqlDbType.BigInt)
                { Value = pIdCliente, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_eliminar_cliente",
                                       new SqlParameter[] { paramIdCliente, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void ActualizarCliente(long pIdCliente,
                                            string pNombreCliente,
                                            double pSaldoCuenta)
        {
            try
            {
                SqlParameter paramIdCliente = new SqlParameter("@idCliente", SqlDbType.BigInt)
                { Value = pIdCliente, Direction = ParameterDirection.Input };
                SqlParameter paramNombreCliente = new SqlParameter("@nombreCliente", SqlDbType.VarChar, 100)
                { Value = pNombreCliente, Direction = ParameterDirection.Input };
                SqlParameter paramSaldoCuenta = new SqlParameter("@saldoCuenta", SqlDbType.Decimal)
                { Value = pSaldoCuenta, Precision = 18, Scale = 2, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_actualizar_cliente",
                                       new SqlParameter[] { paramIdCliente , paramNombreCliente, paramSaldoCuenta, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region "RETIRO_CAJERO"
        public void RealizarRetiro(long pIdCliente,
                                            double pMontoRetiro)
        {
            try
            {
                SqlParameter paramIdCliente = new SqlParameter("@idCliente", SqlDbType.BigInt)
                { Value = pIdCliente, Direction = ParameterDirection.Input };
                SqlParameter paramMontoRetiro = new SqlParameter("@montoRetiro", SqlDbType.Decimal)
                { Value = pMontoRetiro, Precision = 18, Scale = 2, Direction = ParameterDirection.Input };
                SqlParameter paramErrorNume = new SqlParameter("@errorNume", SqlDbType.BigInt)
                { Direction = ParameterDirection.Output };
                SqlParameter paramErrorDesc = new SqlParameter("@errorDesc", SqlDbType.VarChar, 100)
                { Direction = ParameterDirection.Output };
                dataAccess.ExecuteStoredProcedureNonQuery("sp_realizar_retiro",
                                       new SqlParameter[] { paramIdCliente, paramMontoRetiro, paramErrorNume, paramErrorDesc });

                long errorNumero = (long)paramErrorNume.Value;
                string errorDescripcion = (string)paramErrorDesc.Value;


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion

    }
}
