﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace AsociadosWebApi.AccesoDatos
{
    public class MSSQLDataAccess
    {
        private string connectionString;
        public MSSQLDataAccess(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public void ExecuteStoredProcedureNonQuery(string storedProcedureName, SqlParameter[] parameters)
        {
            

            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                try
                {
                    // Abre la conexión si no está abierta
                    if (sqlConnection.State != ConnectionState.Open)
                    {
                        sqlConnection.Open();
                    }

                    // Configura el comando para ejecutar el stored procedure
                    using (SqlCommand command = new SqlCommand(storedProcedureName, sqlConnection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Agrega los parámetros si existen
                        if (parameters != null && parameters.Length > 0)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        // Ejecuta el stored procedure
                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    // Captura y lanza la excepción
                    throw new Exception(ex.Message);
                }
                finally
                {
                    // Asegúrate de cerrar la conexión
                    if (sqlConnection.State == ConnectionState.Open)
                    {
                        sqlConnection.Close();
                    }
                }
            }
        }
        public DataTable ExecuteStoredProcedureReader(string storedProcedureName, SqlParameter[] parameters)
        {
            DataTable data = new DataTable();
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                try
                {
                    if (sqlConnection.State != ConnectionState.Open)
                    {
                        sqlConnection.Open();
                    }

                    using (SqlCommand command = new SqlCommand(storedProcedureName, sqlConnection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        if (parameters != null && parameters.Length > 0)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            data.Load(reader);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            return data;
        }
        public string? ExecuteStoredProcedureNonQueryStringOutParameter(string storedProcedureName, SqlParameter[] parameters, int lengthResult)
        {
            string? result = "";
            using (SqlConnection sqlConnection = new SqlConnection(connectionString))
            {
                try
                {
                    if (sqlConnection.State != ConnectionState.Open)
                    {
                        sqlConnection.Open();
                    }

                    using (SqlCommand command = new SqlCommand(storedProcedureName, sqlConnection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        if (parameters != null && parameters.Length > 0)
                        {
                            command.Parameters.AddRange(parameters);
                        }

                        command.ExecuteNonQuery();

                        // Suponiendo que 'p_RESULTADO' es un parámetro de salida definido como SqlDbType.VarChar en el stored procedure
                        SqlParameter outputParameter = command.Parameters["@p_RESULTADO"];
                        if (outputParameter != null)
                        {
                            result = outputParameter.Value.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            return result;
        }
    }
}
