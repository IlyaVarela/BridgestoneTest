﻿namespace AsociadosWebApi.AccesoDatos
{
    public class EnumBaseDatos
    {
        public  enum TipoArchivo
        {
            ARCHIVO_TRANSACCIONES = 1,
            ARCHIVO_ORDENES_PAGO = 2,
            ARCHIVO_ASIENTOS_CONTABLES = 3,
            ARCHIVO_EXPORTACION_CSV_001 = 4
        }
        public enum EstadoArchivo
        {
            ARCHIVO_LISTADO = 1,
            ARCHIVO_DESCARGADO = 2,
            ARCHIVO_DESENCRIPTADO = 3,
            ARCHIVO_PROCESANDO = 4,
            ARCHIVO_PROCESADO = 5,
            ARCHIVO_ERROR_DESCARGA = 6,
            ARCHIVO_ERROR_DESENCRIPTADO = 7,
            ARCHIVO_ERROR_PROCESADO = 8,
            ARCHIVO_MAX_INTENTOS_DESCARGAR = 9,
            ARCHIVO_MAX_INTENTOS_DESENCRIPTADO = 10,
            ARCHIVO_MAX_INTENTOS_PROCESADO = 11
        }
        public enum EstadoPago
        {
            PAGO_POR_PROCESAR = 0,
            PAGO_PROCESANDO = 1,
            PAGO_PROCESADO = 2,
            PAGO_ERROR_PROCESAR = 3,
            PAGO_MAX_INTENTOS_ERRONEOS = 4
        }
        public enum EstadoAsiento
        {
            ASIENTO_POR_PROCESAR = 0,
            ASIENTO_PROCESANDO = 1,
            ASIENTO_PROCESADO = 2,
            ASIENTO_ERROR_PROCESAR = 3,
            ASIENTO_MAX_INTENTOS_ERRONEOS = 4
        }
        public enum MonedaOW
        {
            COLONES = 188,
            DOLARES = 840
        }
        public enum MonedaCS
        {
            COLONES = 1,
            DOLARES = 2
        }
    }
}
